<?php
    session_destroy();

    include "index.php";
?>