<?php

header("Access-Control-Allow-Origin: http://localhost/rest-api-authentication-example/");
header("Content-Type: html; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'php-jwt-master/src/BeforeValidException.php';
include_once 'php-jwt-master/src/ExpiredException.php';
include_once 'php-jwt-master/src/SignatureInvalidException.php';
include_once 'php-jwt-master/src/JWT.php';

use \Firebase\JWT\JWT;
session_start();

$servername = "localhost";
$username = "fauvisca";
$password = "";
$dbname = "my_fauvisca";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $tip = $_POST['tipologia'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    $sql ="select id from Scoutalent where Nome='$name' and Cognome='$surname' and tipologia='$tip' and Password='$password' and Email='$email'";

    $result = mysqli_query($con, $sql);  
    $count = mysqli_num_rows($result);  

    if (isset($_COOKIE['username'])) 
    {
        include 'accesso.php';
    }
    if($count != 1){

    /*  $credenziali=json_decode(file_get_contents("./privato/cose_segrete.json"));
        $_SESSION["state"]="123456789";
        $clientID=$credenziali->client;
        $clientsecret=$credenziali->secret;

    $key = "accesso";

    $issued_at = time();
    $expiration_time = $issued_at + (5*60 * 1);

    $payload = array(
        "iss" => "http://example.org",
        "aud" => "http://example.com",
        "iat" => $issued_at,
        "exp" => $expiration_time,
        "nbf" => 1357000000,
        "data" => array(

            "utente" => array(
                "nome" => $name,
                "cognome" => $surname
            )
        )
    );
    try
    {
        $jwt = JWT::encode($payload, $key,'HS256'); 
        mail($email, 'Token', $jwt);
        
        include 'token.html';
        $_SESSION['id'] = session_id();
    }
    catch (UnexpectedValueException $e) 
    {
        $res=array("responseCode"=>500,"responseText"=>"Internal Server Error", "text"=>"something went wrong","status"=>false,"error"=>$e->getMessage());   
        http_response_code(500);
        echo json_encode($res);
    } 
    
    require_once './google/vendor/autoload.php';
                              
                            $clientID = '903725800682-sfrcglepaassq1qvfe1rih41hvs2r8j2.apps.googleusercontent.com';
                            $clientSecret = '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';
                            $redirectUri = 'http://fauvisca.altervista.org/Informatica/accesso.php';
                               
                            $client = new Google_Client();
                            $client->setClientId($clientID);
                            $client->setClientSecret($clientSecret);
                            $client->setRedirectUri($redirectUri);
                            $client->addScope("email");
                            $client->addScope("profile");
                            
                            if (isset($_GET['code'])) {
                              $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
                              $client->setAccessToken($token['access_token']);
                            
                              $google_oauth = new Google_Service_Oauth2($client);
                              $google_account_info = $google_oauth->userinfo->get();
                              $email =  $google_account_info->email;
                              $name =  $google_account_info->name;
                              
                            } else {
                              echo "<a href='".$client->createAuthUrl()."'>Google Login</a>";
                            }
    
    */
    if($count == 1)
        {
            $_SESSION["id"]=$sql;

            if(!empty($_POST['rememberMe'])) {

                setcookie("username",$user,time() + 365 * 24 * 60 * 60);
        
            }
            include 'accesso.php';
        }
}
else
{
http_response_code(405);
$res=array("responseCode"=>405,"responseText"=>"Method not Allowed", "methodAllowed"=>"POST");
echo json_encode($res);
}
/*
<!--   <a href="https://id.paleo.bg.it/oauth/authorize?client_id=--><?php //echo $clientID;?><!--&response_type=code&state=--><?php //echo $_SESSION["state"];?><!--&redirect_uri=https://fauvisca.altervista.org/Progetto/main.php">ACCEDI con Paleo ID</a>-->
*/
 }else{
        echo "Errore nel login";
        header("Refresh:0");
    }
    
?>