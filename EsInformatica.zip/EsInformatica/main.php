<?php
session_start();

$servername = "localhost";
$username = "fauvisca";
$password = "";
$dbname = "my_fauvisca";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql ="SELECT COUNT(*) from Scoutalent where tipologia='Talento'";
$result = mysqli_query($con, $sql);  

while($row = $result->fetch_assoc()){
    echo "
    <div class="m-4">
    <div class="card" style="width: 300px;">
        <img src="atleta.svg" class="card-img-top" alt="Sample Image">
        <div class="card-body text-center">
            <h5 class="card-title">$row["Nome"]</h5>
            <h5 class="card-title">$row["Cognome"]</h5>
          	<h5 class="card-title">$row["Tipologia"]</h5>
            "/*<a href="#" class="btn btn-primary">View Profile</a>*/"
        </div>
    </div>
</div>"
}
?>
<!Doctype html>
<html>
<form action="destroy.php">
    <button type="SUBMIT">Uscita</button>
</form>
<html>