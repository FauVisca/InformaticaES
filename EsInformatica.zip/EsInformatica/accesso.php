<?php
    session_start();
?>
<html>
    <head>
        <title>Accesso</title>
    </head>
    <body>
        <div class="">
    <?php
         $id =session_id();

         $sql ="SELECT Nome from Scoutalent where Id ='$id'";
         $result = mysqli_query($con, $sql); 

         echo "Benvenuto nel sito: "+ $result;
    ?>
        </div>
        <div>
        <a href="changepassw.html">Change your password</a>
        </div>
        <form action="destroy.php">
        <button type="submit">LOGOUT</button>
        </form>
    </body>
</html>