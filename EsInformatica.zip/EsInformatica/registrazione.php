<?php
$servername = "localhost";
$username = "fauvisca";
$password = "";
$dbname = "my_fauvisca";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
if($_SERVER["REQUEST_METHOD"] == "POST"){

 $name=$_POST['nome'];
 $surname=$_POST['cognome'];
 $email=$_POST['email'];
 $pass=$_POST['pass'];
 $tipologia=$_POST['tipologia'];

$sql = "INSERT INTO Scoutalent(Nome,Cognome,Email,Passwords,Tipologia)
VALUES ('$name','$surname','$email','$pass','$tipologia')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
  include 'index.html';
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
}
else{
  http_response_code(405);
  header('Content-Type: application/json; charset=utf-8');
}
$conn->close();
?>
